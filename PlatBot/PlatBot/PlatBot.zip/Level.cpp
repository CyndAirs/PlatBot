#include "Level.hpp"


void Level::draw()
{
	this->game->window.setView(levelView);
	this->game->window.clear(sf::Color::Blue);

	sf::Vector2f hpbarpos = levelView.getCenter() - levelView.getSize() * 0.5f + sf::Vector2f(HPBAR_X, HPBAR_Y); //!

	hpbar.draw(game, hpbarpos, playchar.checkHealth());

	sf::Vector2f scorebarpos = levelView.getCenter() - levelView.getSize() * 0.5f + sf::Vector2f(ScBAR_X, ScBAR_Y); //!

	scorebar.draw(game, scorebarpos, points);

	for (std::vector<std::deque<BGElement*>>::iterator it = map.begin(); it != map.end(); it++)
	{
		for (std::deque<BGElement*>::iterator it2 = it->begin(); it2 != it->end(); it2++)
		{
			(*it2)->draw(game);
		}
	}

	for (std::vector<Attack*>::iterator it = attacks.begin(); it != attacks.end(); it++)
	{
		(*it)->draw(game);
	}
	
	playchar.draw(game);

	for (std::vector<Enemy*>::iterator it = enemies.begin(); it != enemies.end(); it++)
	{
		(*it)->draw(game);
	}

}

void corrPos(MobileObject* ptr)
{
	ptr->corrPos();
}

void Level::update(const float dt)
{
	playchar.update(game, map, attacks, dt);

	sf::Vector2f center = levelView.getCenter();

	if (playchar.GetPosition().x > center.x)
	{
		center.x = playchar.GetPosition().x;

		if ((levelView.getSize().x + 32) < (2 * center.x))
		{
			generate();
			center.x -= 16;
			playchar.corrPos();

			for_each(enemies.begin(), enemies.end(), corrPos);

			for_each(attacks.begin(), attacks.end(), corrPos);
		}

		levelView.setCenter(center);
	}

	std::vector<Enemy*>::iterator itenemy;

	for (itenemy = enemies.begin(); itenemy != enemies.end(); itenemy++)
	{
		(*itenemy)->update(game, map, attacks, dt);
	}

	std::vector<Attack*>::iterator itattack;

	for (itattack = attacks.begin(); itattack != attacks.end(); itattack++)
	{
		(*itattack)->update(map, dt);
	}

	bool attackDelete = false;
	itattack = attacks.begin();
	std::string a;
	while (itattack != attacks.end())
	{
		//Sprawdzamy czy atak jest poza plansz�.
		if ((*itattack)->isOutside())
		{
			delete (*itattack);
			itattack = attacks.erase(itattack);
			continue;
		}
		//Sprawdzamy czy ataki fizyczne zako�czy�y si�
		if (typeid(**itattack) == typeid(Hit))
		{
			if ((dynamic_cast<Hit*>(*itattack)->expired()))
			{
				delete (*itattack);
				itattack = attacks.erase(itattack);
				continue;
			}
		}
		//Sprawdzamy czy atack uderza w garcza.	
		if (playchar.checkHit(*itattack))
		{
			attackDelete = true;
		}
		//Sprawdzamy czy atak uderza w jakich� przeciwnik�w
		itenemy = enemies.begin();
		while (itenemy != enemies.end() && (!attackDelete))
		{
			if ((*itenemy)->checkHit(*itattack))
			{
				attackDelete = true;
				if (typeid (**itattack) != typeid(Hit)) break; //Ataki fizyczne mog� uderzy� w wi�cej przeciwnk�w, ale pociski nie
			}
			else itenemy++;
		}

		itenemy = enemies.begin();
		while (itenemy != enemies.end())
		{
			if ((*itenemy)->isOutside())
			{
				delete (*itenemy);
				itenemy = enemies.erase(itenemy);
			}
			else if ((*itenemy)->checkHealth() <= 0)
			{
				delete (*itenemy);
				itenemy = enemies.erase(itenemy);
				points += 1;
			}
			else itenemy++;
		}

		//Sprawdzamy czy atak powinien zosta� usuni�ty
		if (attackDelete)
		{
			delete (*itattack);
			itattack = attacks.erase(itattack);
			attackDelete = false;
		}
		else itattack++;


	}

	if (playchar.checkHealth() == 0)
	{
		retry();
	}
}

void Level::retry()
{
	game->pushState(new Menu(this->game, true));
}

void Level::input()
{
	sf::Event event;

	while (this->game->window.pollEvent(event))
	{
		switch (event.type)
		{
		case sf::Event::Closed:
		{
			game->window.close();
			break;
		}
		}
	}

}


Level::Level(GameManager* game)
{
	this->game = game;
	sf::Vector2f size = sf::Vector2f(VIEW_W, VIEW_H);
	levelView.setSize(size);
	size *= 0.5f;
	levelView.setCenter(size);

	//Generujemy bazow� map�
	defmap =
	{
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 1, 2, 2, 3, 0, 0, 0, 1, 2 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 1, 2, 2, 2, 3, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 0, 0, 0, 1 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
	};


	genMap();
	
	playchar = Player(game, P_START_X, P_START_Y);

	hpbar = HPBar(10, 10, game);

	scorebar = ScoreBar(120, 10, game);
	
}

void delete_BG(BGElement* ptr)
{
	delete ptr;
}

void Level::genMap()
{
	for (std::vector<std::deque<BGElement*>>::iterator it = map.begin(); it != map.end(); it++)
	{
		for_each(it->begin(), it->end(), delete_BG);
		it->clear();
	}
	map.clear();
	for (int i = 0; i < 10; i++)
	{
		std::deque<BGElement*>temp;
		map.push_back(temp);
		for (int j = 0; j < 15; j++)
		{
			switch (defmap[i][j])
			{
			case 0:
			{
				map[i].push_back(new BGElement());
				break;
			}
			case 1:
			{
				map[i].push_back(new BGElement(game, StartBlock, j, i));
				break;
			}
			case 2:
			{
				map[i].push_back(new BGElement(game, MiddleBlock, j, i));
				break;
			}
			case 3:
			{
				map[i].push_back(new BGElement(game, EndBlock, j, i));
				break;
			}
			}
		}
	}
}

void Level::spawn(int x, int y, int type)
{
	Enemy* enemy = new Enemy(game, (x - 1) * TILE_W + E_HB_DIFF_W[type], (y - 1) * TILE_H + E_HB_DIFF_H[type], type);

	enemies.push_back(enemy);
}

void Level::generate()
{
	std::random_device generator;
	std::mt19937 mt(generator());
	std::uniform_real_distribution<double> dice(1, 10);
	int level = int(points/5);
	if (level >= 10) level = 9;
	if (level <= 1) level = 2;

	//Generowanie planu planszy do defmap, genruje linia po linii

	for (int i = 0; i < 10; i++)
	{
		defmap[i].pop_front();

		switch (i)
		{
		case 2:

			defmap[i].push_back(Blank);

			if ((defmap[i + 1][MAP_W - 2] == StartBlock) && ((dice(mt) - level) < 4))
			{
				if (dice(mt) > 5)
				{
					spawn(MAP_W - 1, i, 0);
				}
				else
				{
					spawn(MAP_W - 1, i, 1);
				}
			}

			break;

		case 3:

			switch (defmap[i][MAP_W - 2])
			{

			case Blank:
				if ((dice(mt) / level) > 3)
				{
					defmap[i].push_back(StartBlock);
				}
				else if ((defmap[i][MAP_W - 4] == Blank) && (defmap[i+2][MAP_W - 4] == Blank))
				{
					defmap[i].push_back(StartBlock);
				}
				else
				{
					defmap[i].push_back(Blank);
				}
				break;

			case StartBlock:
				defmap[i].push_back(MiddleBlock);
				break;

			case MiddleBlock:
				if ((dice(mt) / count(defmap[i].begin(), defmap[i].end(), 2)) > 1)
				{
					defmap[i].push_back(MiddleBlock);
				}
				else
				{
					defmap[i].push_back(EndBlock);
				}
				break;


			case EndBlock:
				defmap[i].push_back(Blank);
				break;

			default:
				defmap[i].push_back(Blank);

				break;
			}

			break;

		case 4:

			defmap[i].push_back(Blank);

			if ((defmap[i + 1][MAP_W - 2] == StartBlock) && (dice(mt) - level) < 4)
			{
				if (dice(mt) > 5)
				{
					spawn(MAP_W - 1, i, 0);
				}
				else
				{
					spawn(MAP_W - 1, i, 1);
				}
			}

			break;

		case 5:

			switch (defmap[i][MAP_W - 2])
			{

			case Blank:
				if ((dice(mt) / level) > 1)
				{
					defmap[i].push_back(StartBlock);
				}
				else if ((defmap[i - 2][MAP_W - 4] == Blank) && (defmap[i][MAP_W - 4] == Blank) && (defmap[i + 2][MAP_W - 4] == Blank))
				{
					defmap[i].push_back(StartBlock);
				}
				else
				{
					defmap[i].push_back(Blank);
				}
				break;

			case StartBlock:
				defmap[i].push_back(MiddleBlock);
				break;

			case MiddleBlock:
				if ((dice(mt) / count(defmap[i].begin(), defmap[i].end(), 2)) > 1)
				{
					defmap[i].push_back(MiddleBlock);
				}
				else
				{
					defmap[i].push_back(EndBlock);
				}
				break;


			case EndBlock:
				defmap[i].push_back(Blank);
				break;

			default:
				defmap[i].push_back(Blank);

				break;
			}

			break;

		case 6:

			defmap[i].push_back(0);

			if ((defmap[i + 1][MAP_W - 2] == StartBlock) && (dice(mt) - level) < 4)
			{
				if (dice(mt) > 5)
				{
					spawn(MAP_W - 1, i, 0);
				}
				else
				{
					spawn(MAP_W - 1, i, 1);
				}
			}

			break;

		case 7:

			switch (defmap[i][MAP_W - 2])
			{

			case Blank:
				if ((dice(mt) / level) > 1)
				{
					defmap[i].push_back(StartBlock);
				}
				else if ((defmap[i - 2][MAP_W - 4] == Blank) && (defmap[i][MAP_W - 4] == Blank))
				{
					defmap[i].push_back(StartBlock);
				}
				else
				{
					defmap[i].push_back(Blank);
				}
				break;

			case StartBlock:
				defmap[i].push_back(MiddleBlock);
				break;

			case MiddleBlock:
				if ((dice(mt)/count(defmap[i].begin(), defmap[i].end(), 2)) > 1)
				{
					defmap[i].push_back(MiddleBlock);
				}
				else
				{
					defmap[i].push_back(EndBlock);
				}
				break;


			case EndBlock:
				defmap[i].push_back(Blank);
				break;

			default:
				defmap[i].push_back(Blank);

				break;
			}

			break;

		default:

			defmap[i].push_back(Blank);

			break;
		}

	}
	genMap();
}


Level::~Level()
{
	for (std::vector<std::deque<BGElement*>>::iterator it = map.begin(); it != map.end(); it++)
	{
		for_each(it->begin(), it->end(), delete_BG);
	}

	for (std::vector<Attack*>::iterator it = attacks.begin(); it != attacks.end(); it++)
	{
		delete (*it);
	}

	for (std::vector<Enemy*>::iterator it = enemies.begin(); it != enemies.end(); it++)
	{
		delete (*it);
	}
}