#include "MobileObject.hpp"


void MobileObject::corrPos()
{
	position.x -= TILE_W;
	hitbox.move(-TILE_W, 0);
}



Hitbox MobileObject::getHB()
{
	return hitbox;
}

void MobileObject::draw(GameManager * game)
{
	sf::Sprite sprite;

	sf::Vector2f newpos = sf::Vector2f(position.x + spriteSize.x*0.5f, position.y + spriteSize.y*0.5f);

	sprite.setTextureRect(sf::IntRect(spriteSize.x*frame, spriteSize.y * type, spriteSize.x, spriteSize.y));

	sprite.setTexture(texture);

	sprite.setOrigin(0.5f*spriteSize.x, 0.5f*spriteSize.y);

	if (!faceLeft)
	{
		sprite.scale(-1.f, 1.f);
	}

	sprite.setPosition(newpos);

	game->window.draw(sprite);
}


