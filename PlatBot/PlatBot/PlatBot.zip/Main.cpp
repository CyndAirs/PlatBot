#include "GameManager.hpp"
#include "Menu.hpp"
#include <Windows.h>

int main()
{
	try
	{
		GameManager game;

		game.pushState(new Menu(&game, false));

		game.loop();
	}
	catch (std::exception &ex)
	{
		MessageBoxA(NULL, ex.what(), "Error", MB_ICONERROR | MB_OK);
	}
	

	return 0;
}