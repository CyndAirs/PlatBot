#include "GraphicsManager.hpp"

void GraphicsManager::load()
{
	loadTexture("buttons", "images/buttons.png");

	loadTexture("tiles", "images/tiles.png");

	loadTexture("player", "images/player.png");

	loadTexture("enemies", "images/enemies.png");

	loadTexture("attacks", "images/attacks.png");

	loadTexture("hpbar", "images/hpbar.png");
}

void GraphicsManager::loadTexture(const std::string& texturename, const std::string& filename)
{	
	sf::Texture* texptr = new sf::Texture;

	if (!texptr->loadFromFile(filename))
	{
		throw std::runtime_error("Missing file: " + filename);
	}

	textures[texturename] = texptr;
}

sf::Texture& GraphicsManager::getRef(const std::string& name)
{
	if (textures.count(name))
	{
		return *textures.at(name);
	}
	throw _exception();
}

GraphicsManager::GraphicsManager()
{
	load();
}

GraphicsManager::~GraphicsManager()
{
	for (std::map<std::string, sf::Texture*>::iterator it = textures.begin(); it != textures.end(); ++it)
	{
		delete it->second;
	}
	textures.clear();
}