#include "Hit.hpp"

Hit::Hit(GameManager * game, int type, bool faceLeft, bool friendly, int x, int y) : Attack(game, type, faceLeft, friendly, x, y)
{
	timer = A_TIMER[type];
}

void Hit::update(std::vector<std::deque<BGElement*>> &map, const float dt)
{
	timer -= dt;
}

bool Hit::expired()
{
	if (timer <= 0) return true;
	else return false;
}
