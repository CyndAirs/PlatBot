#include "Hitbox.hpp"



bool Hitbox::checkCollision(Hitbox thitbox)
{
	return hitbox.intersects(thitbox.checkBox());
}

bool Hitbox::checkCollision(sf::Vector2f point)
{
	return hitbox.contains(point);
}

bool Hitbox::checkOnTop(Hitbox thitbox)
{
	if (int(thitbox.checkBox().top + thitbox.checkBox().height) == hitbox.top) return true;
	return false;
}

void Hitbox::move(float x, float y)
{
	hitbox.left += x;
	hitbox.top += y;
}

sf::Vector2f Hitbox::position()
{
	return sf::Vector2f(hitbox.left, hitbox.top);
}

sf::FloatRect Hitbox::checkBox()
{
	return hitbox;
}

Hitbox::Hitbox(int x, int y, int sizex, int sizey)
{
	hitbox = sf::FloatRect(x, y, sizex, sizey);
}