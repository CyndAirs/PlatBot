#include "ScoreBar.hpp"

void ScoreBar::draw(GameManager * game, sf::Vector2f pos, int score)
{
	sf::Text text;

	std::string str = std::to_string(score);

	while (str.size() < 7)
	{
		str = "0" + str;
	}

	position = pos;

	text.setString(str);

	text.setFont(font);

	text.setPosition(sf::Vector2f(position.x + 1, position.y + 1));

	text.setCharacterSize(8);

	text.setColor(sf::Color::Black);

	text.setStyle(sf::Text::Bold);

	game->window.draw(text);
}

ScoreBar::ScoreBar(float x, float y, GameManager * game)
{
	if (!font.loadFromFile("fonts/font.ttf"))
	{
		throw std::runtime_error("Missing file: fonts/font.ttf");
	}

	const_cast<sf::Texture&>(font.getTexture(8)).setSmooth(false);

	position = sf::Vector2f(x, y);
}