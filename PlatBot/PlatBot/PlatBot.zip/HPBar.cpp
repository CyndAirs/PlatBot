#include "HPBar.hpp"

void HPBar::draw(GameManager * game, sf::Vector2f pos, int size)
{
	sf::Sprite sprite;

	position = pos;


	sprite.setTextureRect(sf::IntRect(1, 8, (HPBAR_W - 2) * size / P_HEALTH, HPBAR_H - 2));

	sprite.setTexture(texture);

	sprite.setPosition(sf::Vector2f(position.x + 1, position.y + 1));

	game->window.draw(sprite);



	sprite.setTextureRect(sf::IntRect(0, 0, HPBAR_W, HPBAR_H));

	sprite.setTexture(texture);

	sprite.setPosition(sf::Vector2f(position.x, position.y));

	game->window.draw(sprite);
}

HPBar::HPBar(float x, float y, GameManager * game)
{
	texture = game->textures.getRef("hpbar");
	position = sf::Vector2f(x, y);
}