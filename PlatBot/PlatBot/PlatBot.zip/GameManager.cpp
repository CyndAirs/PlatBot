#include "GameManager.hpp"
#include "State.hpp"

void GameManager::pushState(State* state)
{
	this->states.push_front(state);
	if (states.size() > 2)
	{
		popState();
	}
}


void GameManager::popState()
{
	delete this->states.back();
	this->states.pop_back();
}



State* GameManager::checkState()
{
	if (this->states.empty()) return nullptr;
	return this->states.front();
}

void GameManager::loop()
{
	sf::Clock clock;

	while (this->window.isOpen())
	{
		sf::Time elapsed = clock.restart();
		float time = elapsed.asSeconds();

		if (checkState() == nullptr) continue;
		checkState()->input();
		checkState()->update(time);
		this->window.clear(sf::Color::Black);
		checkState()->draw();
		this->window.display();
	}
}

GameManager::GameManager()
{
	this->window.create(sf::VideoMode(VIEW_W, VIEW_H), "Test", sf::Style::Default);
	this->window.setFramerateLimit(60);
}

GameManager::~GameManager()
{
	while (!this->states.empty()) popState();
}