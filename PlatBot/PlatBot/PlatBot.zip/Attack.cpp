#include "Attack.hpp"



bool Attack::isOutside()
{
	int x = (hitbox.checkBox().left + hitbox.checkBox().width / 2) / TILE_W;

	if ((x < 0) || (x >(MAP_W))) return true;
	return false;
}

bool Attack::checkFriendly()
{
	return isFriendly;
}

Attack::Attack(GameManager * game, int type, bool faceLeft, bool friendly, int x, int y) : isFriendly(friendly)
{
	frame = 0;
	this->type = type;
	texture = game->textures.getRef("attacks");
	hitbox = Hitbox(x, y, A_HB_SIZE_W[type], A_HB_SIZE_H[type]);
	position = sf::Vector2f(x - A_HB_DIFF_W[type], y - A_HB_DIFF_H[type]);
	this->faceLeft = faceLeft;
	spriteSize = sf::Vector2i(A_SPRITE_W, A_SPRITE_H);
}



