#include "Projectile.hpp"

Projectile::Projectile(GameManager * game, int type, bool faceLeft, bool friendly, int x, int y, int speed) : Attack(game, type, faceLeft, friendly, x, y), speed(speed)
{

}

void Projectile::update(std::vector<std::deque<BGElement*>> &map, const float dt)
{
	if (faceLeft == true) move(-speed * dt);
	else move(speed * dt);
	position = sf::Vector2f(hitbox.checkBox().left - A_HB_DIFF_W[type], hitbox.checkBox().top - A_HB_DIFF_W[type]);
}

void Projectile::move(float x)
{
	hitbox.move(x, 0);
}