#include "DamagableObject.hpp"

bool DamagableObject::damage(int x)
{
	if (health <= 0) return false;
	health-=x;
	return true;


}

int DamagableObject::checkHealth()
{
	return health;
}