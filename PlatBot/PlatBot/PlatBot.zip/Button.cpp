#include "Button.hpp"

Button::Button(ButtonAction action, const std::string & texname, GameManager * game)
{
	
	
	this->action = action;
	
	texpos = sf::Vector2i(0, B_SIZE_Y * action);

	hitbox = Hitbox(B_POS_X[action], B_POS_Y[action], B_SIZE_X, B_SIZE_Y);

	texture = game->textures.getRef(texname);
}

void Button::draw(GameManager * game)
{
	sf::Sprite sprite;

	sf::Vector2f size(hitbox.checkBox().width, hitbox.checkBox().height);

	sf::RectangleShape shape(size);

	sprite.setTextureRect(sf::IntRect(texpos.x, texpos.y, hitbox.checkBox().width, hitbox.checkBox().height));

	sprite.setTexture(texture);

	sprite.setPosition(sf::Vector2f(hitbox.checkBox().left, hitbox.checkBox().top));
	
	game->window.draw(sprite);

}

bool Button::CheckCollision(sf::Vector2f mpos)
{
	return hitbox.checkCollision(mpos);
}

const ButtonAction Button::ActionName()
{
	return action;
}



