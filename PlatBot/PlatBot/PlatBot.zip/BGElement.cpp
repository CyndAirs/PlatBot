#include "BGElement.hpp"


Hitbox BGElement::checkHB()
{
	return hitbox;
}



BGElement::BGElement() :
id(Blank)
{}

void BGElement::draw(GameManager* game)
{
	if (id != 0) // Nie rysujemy pustego pola
	{
		sf::Sprite sprite;

		sprite.setTextureRect(sf::IntRect((id - 1) * TILE_W, 0, TILE_W, TILE_H));

		sprite.setTexture(texture);

		sprite.setPosition(pos.x, pos.y);

		game->window.draw(sprite);
	}
}

BgId BGElement::checkID()
{
	return id;
}

BGElement::BGElement(GameManager* game, BgId id, int cox, int coy) : id(id)
{
	pos = sf::Vector2i(TILE_W * cox, TILE_H * coy);
	texture = game->textures.getRef("tiles");
	hitbox = Hitbox(pos.x + BG_HB_DIFF_W[id], pos.y + BG_HB_DIFF_H[id], BG_HB_SIZE_W[id], BG_HB_SIZE_H[id]);
}

